import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Country } from '../models/country';
import { isIndependent } from '../state/countries/countries.reducer';

@Injectable({
  providedIn: 'root',
})
export class CountryService {
  constructor(private http: HttpClient) {}

  getAllCountries = (): Observable<Country[]> => {
    const path = 'https://restcountries.com/v3.1/all';
    return this.http.get<any[]>(path).pipe(
      map((countries) => {
        // transform data
        return countries.map((country) => ({
          name: country.name.common,
          nameEN: country.name.common,
          nameFR: country.translations.fra.common,
          isIndependent: country.independent,
        }));
      })
    );
  };
}
