import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { EffectsModule } from '@ngrx/effects';
import {
  ActionReducerMap,
  MetaReducer,
  ActionReducer,
  StoreModule,
} from '@ngrx/store';
// import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from 'src/environments/environment';
import * as fromCountries from './countries/countries.reducer';
import { AuthenticationEffects } from './countries/countries.effects';
import { EffectsModule } from '@ngrx/effects';

export interface State {
  countries: fromCountries.State;
}

export const reducers: ActionReducerMap<State> = {
  countries: fromCountries.reducer,
};
export const effects = [AuthenticationEffects];


const logger = (reducer: ActionReducer<State>): ActionReducer<State> => {
  return (state: State | undefined, action: any) => {
    console.log('state', state);
    console.log('action', action);
    return reducer(state, action);
  };
};

export const metaReducers: MetaReducer<State>[] = !environment.production
  ? [logger]
  : [];


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StoreModule.forRoot(reducers, { metaReducers }),
    EffectsModule.forRoot(effects),
    // !environment.production ? StoreDevtoolsModule.instrument() : [],
  ],
})
export class StateModule {}
