import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, switchMap } from 'rxjs/operators';
import {
  getCountryListActions,
  getCountryListFailActions,
  getCountryListSuccessActions,
} from './countries.actions';
import { CountryService } from 'src/app/services/country.service';
import { of } from 'rxjs';

@Injectable()
export class AuthenticationEffects {
  constructor(
    private actions$: Actions,
    private countryService: CountryService
  ) {}

  getAllCountries$ = createEffect(() =>
    this.actions$.pipe(
      ofType(getCountryListActions),
      switchMap(() =>
        this.countryService.getAllCountries().pipe(
          map((countries) => getCountryListSuccessActions({ countries })),
          catchError((error) => of(getCountryListFailActions({ error })))
        )
      )
    )
  );
}
