import { Action, createReducer, createSelector, on } from '@ngrx/store';
import * as CountryActions from './countries.actions';
import { Country } from 'src/app/models/country';

export interface State {
  loading: boolean;
  countries: Country[];
  displayedCountries: Country[];
  filter: string;
  lang: 'EN' | 'FR';
  isIndependent: boolean;
  error: string;
}

export const initialState: State = {
  loading: false,
  countries: [],
  displayedCountries: [],
  filter: '',
  lang: 'EN',
  isIndependent: true,
  error: ''
};

const countriesReducer = createReducer(
  initialState,
  on(CountryActions.getCountryListActions, (state) => ({
    ...state,
    loading: true,
  })),
  on(CountryActions.getCountryListSuccessActions, (state, { countries }) => ({
    ...state,
    loading: false,
    displayedCountries: countries,
    countries,
  })),
  on(CountryActions.getCountryListFailActions, (state, { error }) => ({
    ...state,
    loading: false,
    countries: [],
    displayedCountries: []
  })),
  on(CountryActions.filterCountries, (state, { filter }) => ({
    ...state,
    filter,
    displayedCountries: filterCountries(
      state.countries,
      filter,
      state.lang,
      state.isIndependent
    ),
  })),
  on(CountryActions.changeLang, (state, { lang }) => ({
    ...state,
    lang,
    displayedCountries: filterCountries(
      state.countries,
      state.filter,
      lang,
      state.isIndependent
    ),
  })),
  on(CountryActions.setIndependance, (state, { isIndependent }) => ({
    ...state,
    isIndependent,
    displayedCountries: filterCountries(
      state.countries,
      state.filter,
      state.lang,
      isIndependent
    ),
  }))
);

export const reducer = (state: State | undefined, action: Action) => {
  return countriesReducer(state, action);
};

export const selectCountries = (state: { countries: any }) => state.countries;
export const isLoading = createSelector(
  selectCountries,
  (state: State) => state.loading
);
export const getDisplayedCountries = createSelector(
  selectCountries,
  (state: State) => state.displayedCountries
);
export const getLang = createSelector(
  selectCountries,
  (state: State) => state.lang
);
export const isIndependent = createSelector(
  selectCountries,
  (state: State) => state.isIndependent
);
export const getError = createSelector(
  selectCountries,
  (state: State) => state.error
);

const filterCountries = (
  allCountries: Country[],
  criteria: string,
  lang: 'EN' | 'FR',
  isIndependent: boolean
): Country[] => {
  return allCountries
    .map((country: Country) => ({
      ...country,
      name: country[`name${lang}`],
    }))
    .filter(
      (country) =>
        country.name.toUpperCase().includes((criteria || '').toUpperCase()) &&
        country.isIndependent === isIndependent
    );
};
