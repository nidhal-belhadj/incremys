import { createAction, props } from '@ngrx/store';
import { Country } from 'src/app/models/country';

export const getCountryListActions = createAction('Get Country List');

export const getCountryListSuccessActions = createAction(
  'Get Country List Success',
  props<{ countries: Country[] }>()
);

export const getCountryListFailActions = createAction(
  'Get Country List Fail',
  props<{ error: string }>()
);

export const filterCountries = createAction(
  'filter countries',
  props<{ filter: string }>()
);

export const changeLang = createAction(
  'Change Lang',
  props<{ lang: 'EN' | 'FR' }>()
);

export const setIndependance = createAction(
  'set Independence',
  props<{ isIndependent: boolean }>()
);
