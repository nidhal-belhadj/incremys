import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import {
  getDisplayedCountries,
  getError,
  getLang,
  isIndependent,
  isLoading,
  State,
} from './state/countries/countries.reducer';
import {
  changeLang,
  filterCountries,
  getCountryListActions,
  setIndependance,
} from './state/countries/countries.actions';
import { Observable } from 'rxjs';
import { Country } from './models/country';
import { ColDef } from 'ag-grid-community';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'webapp';

  loading$: Observable<boolean> | undefined;
  countries$: Observable<Country[]> | undefined;
  filter$: Observable<string> | undefined;
  lang$: Observable<'EN' | 'FR'> | undefined;
  isIndependent$: Observable<boolean> | undefined;
  error$: Observable<string> | undefined;
  

  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 150,
    sortable: true,
  };

  columnDefs = [{ field: 'name' }, { field: 'isIndependent' }];

  constructor(private store: Store<State>) {}

  ngOnInit(): void {
    this.loading$ = this.store.pipe(select(isLoading));
    this.countries$ = this.store.pipe(select(getDisplayedCountries));
    this.lang$ = this.store.pipe(select(getLang));
    this.isIndependent$ = this.store.pipe(select(isIndependent));
    this.error$ = this.store.pipe(select(getError));
    this.store.dispatch(getCountryListActions());
  }

  filterList(filter: string) {
    this.store.dispatch(filterCountries({ filter }));
  }

  changeLang(lang: 'EN' | 'FR') {
    this.store.dispatch(changeLang({ lang }));
  }

  setIndependent(event: any) {
    this.store.dispatch(
      setIndependance({ isIndependent: event.target['checked'] })
    );
  }
}
