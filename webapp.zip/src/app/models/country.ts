export interface Country {
  name: string;
  nameEN: string;
  nameFR: string;
  isIndependent: boolean;
}
